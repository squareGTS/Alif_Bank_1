import UIKit

//-1

var array = [1, 2, -3, 4, -5, 6, 7, 8, 9, -10, -11, 12]
var count = 0

array.forEach {
    count += 1
    if $0 < 0 {
        array.insert(abs($0), at: count)
        array.remove(at: count - 1)
    }
}

print("change negative value to positive: \(array)")

//-2

var sortAfter = array.sorted(by: >)
var sortBefore = array.sorted(by: <)

print("sort After: \(sortAfter)")
print("sort Before: \(sortBefore)")

//-3

var min = array.min()
var max = array.max()

print("min: \(min ?? 0)")
print("max: \(max ?? 0)")

//-4

var sum = array.reduce(0, +)

print("Sum of Array is: \(sum)")
